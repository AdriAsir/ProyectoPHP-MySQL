<!--
  Pie de página estático.
-->
<div class="container">
  <footer style="position: absolute; bottom: 0; width: 80%; height: 1px" class="py-3 my-4" >
    <p class="text-center text-muted"> </p>
  </footer>
</div>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">

</body>
</html>